from django.urls import path
from . import views
from .views import *

urlpatterns = [
    path("portfolio/",views.portfolio,name = "portfolio"),
    path("", views.sign_in, name="sign_in"),
    path("signup/", views.sign_up, name="sign_up"),
    path("account_details/", account_details, name='account_details'),
    path('extract/', extract_data, name='extract_data'),
]
