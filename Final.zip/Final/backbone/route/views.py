from django.shortcuts import render,redirect
from django.http import HttpResponse

from .models import Account
from django.http import HttpResponseRedirect
from django.urls import reverse
from django.db import IntegrityError
from django.contrib import messages

# Create your views here.
def sign_in(request):
    return render(request, "pages/signin.html")

def sign_up(request):
    return render(request, "pages/Signup.html")

def portfolio(request):
    return render(request, "pages/portfolio.html")

def account_details(request):
    if request.method == 'POST':
        fname = request.POST.get('fname')
        lname = request.POST.get('lname')
        mname = request.POST.get('mname')
        aname = request.POST.get('aname')
        email_id = request.POST.get('email_id')
        pword = request.POST.get('pword')
        cpword = request.POST.get('cpword')

        # Create a new account entry in the database using the sign up model
        try:
            Account.objects.create(fname=fname, lname=lname, mname=mname, aname=aname, email_id=email_id, pword=pword, cpword=cpword) 
            messages.success(request, "Your account has been created")
            return HttpResponseRedirect(reverse("sign_in"))
        except IntegrityError:
            messages.warning(request,"Username already taken")
            return HttpResponseRedirect(reverse("sign_up"))
    else:
        return HttpResponse("Invalid request method.")
    
def index(request):
    if not request.user.is_authenticated:
        return HttpResponseRedirect(reverse("sign_in"))
    

def extract_data(request):
    if request.method == "POST":
        anname = request.POST.get("eian")
        paword = request.POST.get("password")
        
        try:
            Account.objects.get(pk=anname,pword=paword)
            user = True
        except Account.DoesNotExist:
            user = False

        if user==True:
            return redirect('portfolio')
        else:
            messages.error(request, "Invalid Credentials")
            
            return HttpResponseRedirect(reverse("sign_in"))     
        
    return HttpResponse("not working.")
