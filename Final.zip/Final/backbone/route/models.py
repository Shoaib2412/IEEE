from django.db import models

# Create your models here.

class Account(models.Model):
    fname= models.CharField(max_length=255)
    lname= models.CharField(max_length=255)
    mname= models.CharField(max_length=255)
    aname= models.CharField(max_length=255,primary_key= True)
    email_id = models.EmailField()
    pword = models.CharField(max_length=100)
    cpword = models.CharField(max_length=100)

    #def __str__(self):
        #return f"{self.fname} - {self.lname} - {self.mname} - {self.aname} - {self.email_id} - {self.pword} - {self.cpword}"

